import XCTest
import SwiftTreeSitter
import TreeSitterLuaFormatString

final class TreeSitterLuaFormatStringTests: XCTestCase {
    func testCanLoadGrammar() throws {
        let parser = Parser()
        let language = Language(language: tree_sitter_lua_format_string())
        XCTAssertNoThrow(try parser.setLanguage(language),
                         "Error loading LuaFormatString grammar")
    }
}
