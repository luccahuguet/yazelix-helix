#ifndef TREE_SITTER_LUA_FORMAT_STRING_H_
#define TREE_SITTER_LUA_FORMAT_STRING_H_

typedef struct TSLanguage TSLanguage;

#ifdef __cplusplus
extern "C" {
#endif

const TSLanguage *tree_sitter_lua_format_string(void);

#ifdef __cplusplus
}
#endif

#endif // TREE_SITTER_LUA_FORMAT_STRING_H_
