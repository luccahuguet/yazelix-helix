# tree-sitter-lua-format-string

tree-sitter grammar for Lua's `string.format` syntax. Also works with the equivalent function in [Luau](https://luau.org/).

## Showcase

Editor: [Helix](https://helix-editor.com/)

![showcase](./docs/showcase.png)

## References used

- https://www.lua.org/manual/5.4/manual.html#pdf-string.format
