print(string.format("hello %s", "world"))
print(string.format("lua's major version is %d, and it's full is %1.1f", 5, 5.4))

print(string.format("width %10.d",  10))
print(string.format("and precision %.5f",  0.5))

print(string.format("flags %#+- 0G", 3.14))

print(("The Danish word for lua is %s"):format("Måne"))
