/**
 * @file LuaFormatString grammar for tree-sitter
 * @author kpbaks <kristoffer.pbs@tuta.io>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

module.exports = grammar({
  name: "lua_format_string",

  // whitespace is meaningful, so we disallow any kind of extra nodes,
  // to avoid having to write `token.immediate(...)` everywhere.
  extras: $ => [],

  rules: {
    format_string: $ =>
      seq(
        $.text,
        repeat(
          seq(
            $._maybe_format,
            $.text
          )
        )
      ),

    _maybe_format: $ => choice($.escaped_percent_sign, $.directive),

    // "conversion specifiers and modifiers F, n, *, h, L, and l are not supported" (https://www.lua.org/manual/5.4/manual.html#pdf-string.format:~:text=conversion%20specifiers%20and%20modifiers%20F%2C%20n%2C%20*%2C%20h%2C%20L%2C%20and%20l%20are%20not%20supported)
    // The ISO/IEC 9899:2024 spec uses the word "directive" for this
    directive: $ => seq(
      "%",
      // NOTE: multiple usages of the same flag in a verb is not malformed
      // e.g. "%## ++s" is equivalent to "%# +s"
      // Therefore we can simply use `repeat()` instead of writing an external scanner
      repeat($.flag),
      optional($._width_and_precision),
      // NOTE: Lua format string deviates from ISO C sprintf by not allowing optional length modifiers, as they do not make sense for the numeric types available in it.
      $.conversion_specifier,
    ),

    // NOTE: Lua format string deviates from ISO C sprintf by not allowing asterisk '*' for width and precision.
    // NOTE: "Both width and precision, when present, are limited to two digits" (https://www.lua.org/manual/5.4/manual.html#pdf-string.format:~:text=Both%20width%20and%20precision%2C%20when%20present%2C%20are%20limited%20to%20two%20digits)
    width: $ => /([0-9]|[1-9][0-9])/,
    precision: $ => /([0-9]|[1-9][0-9])/,
    _width_and_precision: $ =>
      choice(
        // %8d
        // %8.d
        // %8.2f
        seq(
          $.width,
          optional("."),
          optional($.precision),
        ),
        // %.2f
        seq(".", $.precision)
      ),

    conversion_specifier: _ =>
      choice(
        "a",
        "A",
        "b",
        "B",
        "c",
        "d",
        "e",
        "E",
        "f",
        "g",
        "G",
        "i",
        "o",
        "u",
        "p", // pointer
        "q", // "does not support flags, width, precision" (https://www.lua.org/manual/5.4/manual.html#pdf-string.format:~:text=This%20specifier%20does%20not%20support%20modifiers%20(flags%2C%20width%2C%20precision))
        "s", // string
        "u",
        "x",
        "X"
      ),

    escaped_percent_sign: _ => "%%",

    flag: _ => choice("+", "-", "#", " ", "0"),

    text: _ => /[^%]*/


  }
});
