test:-
  [G|[]].
