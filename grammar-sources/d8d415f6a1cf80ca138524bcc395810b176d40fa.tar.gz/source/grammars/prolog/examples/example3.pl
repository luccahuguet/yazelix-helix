predicate. % g
