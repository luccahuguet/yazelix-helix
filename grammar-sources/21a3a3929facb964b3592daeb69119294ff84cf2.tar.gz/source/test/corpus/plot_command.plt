============
basic function plot
============

plot sin(x)

----

(source_file
  (plot_command
    (plot_item_list
      (plot_item
        (expression
          (function_call
            (builtin_function)
            (expression_list
              (expression
                (identifier)))))))))

============
basic plot of two functions
============

plot sin(x), cos(x)

----

(source_file
  (plot_command
    (plot_item_list
      (plot_item
        (expression
          (function_call
            (builtin_function)
            (expression_list
              (expression
                (identifier))))))
      (plot_item
        (expression
          (function_call
            (builtin_function)
            (expression_list
              (expression
                (identifier)))))))))

============
basic plot of data
============

plot 'data.txt' using 1:2

----

(source_file
  (plot_command
    (plot_item_list
      (plot_item
        (expression
          (string))
        (plot_option
          (using_clause
            (expression
              (number))
            (expression
              (number))))))))

============
advanced plot of data
============

plot 'data.txt' using 1:2 with lines title "Line plot"

----

(source_file
  (plot_command
    (plot_item_list
      (plot_item
        (expression
          (string))
        (plot_option
          (using_clause
            (expression
              (number))
            (expression
              (number))))
        (plot_option
          (with_clause
            (identifier)))
        (plot_option
          (title_clause
            (string)))))))

============
plot of expression
============

plot x**2 + 3*x - 5

----

(source_file
  (plot_command
    (plot_item_list
      (plot_item
        (expression
          (expression
            (expression
              (expression
                (expression
                  (identifier))
                (operator)
                (expression
                  (number)))
              (operator)
              (expression
                (number)))
            (operator)
            (expression
              (identifier)))
          (operator)
          (expression
            (number)))))))
