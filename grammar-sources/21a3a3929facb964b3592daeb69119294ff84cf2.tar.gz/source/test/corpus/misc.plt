====================
multiple statements in one line
====================

x = 3; y=8;
a=1; b = 2;c=3

----

(source_file
  (assignment
    (identifier)
    (expression
      (number)))
  (assignment
    (identifier)
    (expression
      (number)))
  (assignment
    (identifier)
    (expression
      (number)))
  (assignment
    (identifier)
    (expression
      (number)))
  (assignment
    (identifier)
    (expression
      (number))))

====================
print & sprintf
====================

print sprintf("%d, %f", 42, 3.14159)

----

(source_file
  (print_command
    (expression_list
      (expression
        (function_call
          (builtin_function)
          (expression_list
            (expression
              (string))
            (expression
              (number))
            (expression
              (number))))))))
