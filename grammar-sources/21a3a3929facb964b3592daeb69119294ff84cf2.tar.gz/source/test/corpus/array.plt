====================
array definition
====================

array x[8]
n = 16
array y[n]

----

(source_file
  (array_definition
    (identifier)
    (number))
  (assignment
    (identifier)
    (expression
      (number)))
  (array_definition
    (identifier)
    (identifier)))

====================
array assignment
====================

x[1] = sin(0)
y[n-1] = cos(0)

----

(source_file
  (assignment
    (identifier)
    (expression
      (number))
    (expression
      (function_call
        (builtin_function)
        (expression_list
          (expression
            (number))))))
  (assignment
    (identifier)
    (expression
      (expression
        (identifier))
      (operator)
      (expression
        (number)))
    (expression
      (function_call
        (builtin_function)
        (expression_list
          (expression
            (number)))))))

====================
use of array in an exrpession
====================

foo = x[8] + x[i]

----

(source_file
  (assignment
    (identifier)
    (expression
      (expression
        (identifier)
        (expression
          (number)))
      (operator)
      (expression
        (identifier)
        (expression
          (identifier))))))
