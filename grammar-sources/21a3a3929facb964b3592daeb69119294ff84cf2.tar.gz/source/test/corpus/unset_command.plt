====================
unset command
====================

unset xrange

----

(source_file
  (unset_command
    (set_keyword)))
