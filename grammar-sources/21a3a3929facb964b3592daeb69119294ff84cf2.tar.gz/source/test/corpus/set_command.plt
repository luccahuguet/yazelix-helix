====================
set terminal basic
====================

set terminal pngcairo

----

(source_file
  (set_command
    (set_keyword)
    (set_arguments
      (set_argument
        (identifier)))))

====================
set terminal advanced
====================

set term gif animate delay 5 size 1920,1080

----

(source_file
  (set_command
    (set_keyword)
    (set_arguments
      (set_argument
        (identifier))
      (set_argument
        (identifier))
      (set_argument
        (identifier))
      (set_argument
        (number))
      (set_argument
        (identifier))
      (set_argument
        (number)
        (number)))))

====================
set range basic
====================

set xrange [-4:200]

----

(source_file
  (set_command
    (set_keyword)
    (set_arguments
      (range
        (expression
          (expression
            (number)))
        (expression
          (number))))))

====================
set range one end open
====================

set yrange [5:*]

----

(source_file
  (set_command
    (set_keyword)
    (set_arguments
      (range
        (expression
          (number))))))
