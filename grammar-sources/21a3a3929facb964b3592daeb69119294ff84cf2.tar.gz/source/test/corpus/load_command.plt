====================
basic load
====================

load "myscript.plt"

----

(source_file
  (load_command
    (string)))
