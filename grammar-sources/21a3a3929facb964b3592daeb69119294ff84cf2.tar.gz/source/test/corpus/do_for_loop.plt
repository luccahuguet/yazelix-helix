==============================
do for with in-line body
==============================

do for [i=1:5] plot sin(i*x)

----

(source_file
  (loop
    (iterator
      (identifier)
      (expression
        (number))
      (expression
        (number)))
    (do_clause
      (plot_command
        (plot_item_list
          (plot_item
            (expression
              (function_call
                (builtin_function)
                (expression_list
                  (expression
                    (expression
                      (identifier))
                    (operator)
                    (expression
                      (identifier))))))))))))

==============================
do for with {} body
==============================

do for [j=0:10:2] {
    plot cos(j*x)
    plot sin(j*x)
}

----

(source_file
  (loop
    (iterator
      (identifier)
      (expression
        (number))
      (expression
        (number))
      (expression
        (number)))
    (do_clause
      (plot_command
        (plot_item_list
          (plot_item
            (expression
              (function_call
                (builtin_function)
                (expression_list
                  (expression
                    (expression
                      (identifier))
                    (operator)
                    (expression
                      (identifier)))))))))
      (plot_command
        (plot_item_list
          (plot_item
            (expression
              (function_call
                (builtin_function)
                (expression_list
                  (expression
                    (expression
                      (identifier))
                    (operator)
                    (expression
                      (identifier))))))))))))

==============================
nested loops
==============================

do for [k=1:3] {
    do for [l=1:2] plot k*l*x
}

----

(source_file
  (loop
    (iterator
      (identifier)
      (expression
        (number))
      (expression
        (number)))
    (do_clause
      (loop
        (iterator
          (identifier)
          (expression
            (number))
          (expression
            (number)))
        (do_clause
          (plot_command
            (plot_item_list
              (plot_item
                (expression
                  (expression
                    (expression
                      (identifier))
                    (operator)
                    (expression
                      (identifier)))
                  (operator)
                  (expression
                    (identifier)))))))))))
