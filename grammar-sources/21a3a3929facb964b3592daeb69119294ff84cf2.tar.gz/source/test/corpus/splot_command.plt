====================
basic splot
====================

splot x*y

----

(source_file
  (splot_command
    (plot_item_list
      (plot_item
        (expression
          (expression
            (identifier))
          (operator)
          (expression
            (identifier)))))))

====================
complex splot
====================

splot datafile using 1:2:($3/$4) with points notitle, \
      sin(x) + cos(int(y+0.5)) notitle

----

(source_file
  (splot_command
    (plot_item_list
      (plot_item
        (expression
          (identifier))
        (plot_option
          (using_clause
            (expression
              (number))
            (expression
              (number))
            (expression
              (expression
                (expression
                  (expression
                    (number))
                  (operator)
                  (expression
                    (expression
                      (number))))))))
        (plot_option
          (with_clause
            (identifier)))
        (plot_option))
      (plot_item
        (expression
          (expression
            (function_call
              (builtin_function)
              (expression_list
                (expression
                  (identifier)))))
          (operator)
          (expression
            (function_call
              (builtin_function)
              (expression_list
                (expression
                  (function_call
                    (identifier)
                    (expression_list
                      (expression
                        (expression
                          (identifier))
                        (operator)
                        (expression
                          (number))))))))))
        (plot_option)))))
