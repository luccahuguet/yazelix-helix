====================
basic variable definition
====================

x = 42

----

(source_file
  (assignment
    (identifier)
    (expression
      (number))))

====================
variable definition from expression
====================

x = -(sin(42) ** 7)

----

(source_file
  (assignment
    (identifier)
    (expression
      (expression
        (expression
          (expression
            (function_call
              (builtin_function)
              (expression_list
                (expression
                  (number)))))
          (operator)
          (expression
            (number)))))))
