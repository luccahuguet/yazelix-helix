====================
simple fit
====================

fit f(x) 'data.txt' using 1:2 via a

----

(source_file
  (fit_command
    (expression
      (function_call
        (identifier)
        (expression_list
          (expression
            (identifier)))))
    (string)
    (expression
      (number))
    (expression
      (number))
    (identifier)))

====================
fit with math
====================

fit f(x) 'data.txt' using 1:2:($3 * $4 / ($3 + $4)) via alpha, beta, gamma

----

(source_file
  (fit_command
    (expression
      (function_call
        (identifier)
        (expression_list
          (expression
            (identifier)))))
    (string)
    (expression
      (number))
    (expression
      (number))
    (expression
      (expression
        (expression
          (expression
            (number))
          (operator)
          (expression
            (expression
              (expression
                (number))
              (operator)
              (expression
                (expression
                  (expression
                    (expression
                      (number))
                    (operator)
                    (expression
                      (expression
                        (number)))))))))))
    (identifier)
    (identifier)
    (identifier)))
