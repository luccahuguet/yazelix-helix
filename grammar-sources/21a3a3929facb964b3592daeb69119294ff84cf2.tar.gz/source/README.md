Tree Sitter Grammar for the Gnuplot Scripting Language
======================================================

This provides a minimal and basic [tree-sitter][] grammar for [gnuplot][]
language.

[tree-sitter]: https://tree-sitter.github.io/tree-sitter/
[gnuplot]: http://gnuplot.info/

Related Work
------------

https://github.com/dpezto/tree-sitter-gnuplot already provides a very
sophisticated and complete gnuplot grammar.

The downside of the grammar in that repo is that the generated C source is
870K lines of code and building the WASM version of the parse runs into the
OOM reaper on a 64 GiB RAM system.

This grammar is a lot less ambitious with correctness and completeness. It aims
to be good enough for basic syntax highlighting while still being fast.
