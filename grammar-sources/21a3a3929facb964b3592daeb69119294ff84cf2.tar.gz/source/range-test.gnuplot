#!/usr/bin/gnuplot

datafile = "range-test-2025-08-21.csv"

set datafile separator ","

# Standard log-distance path loss using the ns-3 simulation parameters
# We fit the reception probability against the theoretical RX power, which
# is similar to fitting against the distance but easier to integrate.
refdist = 1
refloss = 7.7
txpower = 22
lossexp = 3.76

pathloss(d) = 10 * lossexp * log10(d/refdist)
rxpower(d) = txpower - refloss - pathloss(d)

# Assuming noise floor to be at -100 dBm based on the data reported in
# https://www.thethingsnetwork.org/forum/t/spectrum-analyser-on-eu-868-mhz/33039/4
# > As reported by @LoRaTracker, most noise floor measurements show -105 to
# > -110 dBm - except in heavy industrial environments where it’s higher, often
# > -around -100 dBm and can be very intermittent as machinery starts/stops
# > -and can temporarily rise as high as -90 dBm, which reduces range very
# > -significantly.

# Formula for packet error rate taken from equation 7 from Szafranski et al.,
# https://www.areinhardt.de/publications/2025/Szafranski_WoWMoM_2025.pdf
#   PER(SNR) = L / (1 + exp(-k * (SNR - x0)))
# with SNR = RSSI - NOISE and L = 1 (L is max PER)
#   PER(RSSI, k, x0) = 1 / (1 + exp(-k * (RSSI - NOISE - x0)))
# substituting NOISE - x0 by x0 then yields:
#   PER(RSSI, k, x0) = 1 / (1 + exp(-k * (RSSI - x0)))
# inserting rxpower(d) for RSSI then yields:
PER(d, k, x0) = 1 / (1 + exp(-k * (rxpower(d) - x0)))
# The packet reception rate (round trip) is then
#   PRR(d, k, x0) = (1 - PER(d, k, x0)) ** 2
# Assuming we have some loss due to active interference with a probability of
# 1-m, we get
PRR(d, k, x0, m) = m * (1 - PER(d, k, x0))

# fitting for each spreading factor individually, as per Szafranski et al.
k_SF7 = -1.1
x0_SF7 = -7.7
m_SF7 = 0.95
#fit PRR(x, k_SF7, x0_SF7, m_SF7) datafile using (($2==7)?$1:1/0):($3/$4) via k_SF7, x0_SF7, m_SF7

set xlabel "Distance [m]"
set ylabel "Spreading Factor"
set zlabel "Reception Rate"

set zrange [0:1]
set xrange [0:4000]
set ytics (7,8,9,10,11,12)

set term gif animate delay 5 size 1920,1080
set output "range-test.gif"
set border back
set tics back
set xtics nomirror
set ytics nomirror
set ztics nomirror
set xyplane relative 0

reception_rate(d, sf) = (\
    sf == 7 ? 1 - PRR(d, k_SF7, x0_SF7, m_SF7) :\
    1/0)

do for [ang=1:360:1] {
    set view 60, ang
    splot datafile using 1:2:($3/$4) with points notitle, \
          reception_rate(x, int(y+0.5)) notitle
}
