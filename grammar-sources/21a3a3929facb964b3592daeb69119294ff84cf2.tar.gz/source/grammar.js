/**
 * @file Grammar for the Gnuplot scripting language
 * @author Marian Buschsieweke <marian.buschwieweke@posteo.net>
 * @license 0BSD
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

// grammar.js
// A basic but extensible Tree-sitter grammar for GNUplot

export default grammar({
  name: 'gnuplot',

  extras: $ => [
    /[\t ]/,
    $.comment,
    $._escaped_newline
  ],

  rules: {
    source_file: $ =>
      seq(
        // parse one line at a time
        repeat(seq(
          optional($._statement),
          choice($._newline, ';')
        )),
        // final statement may not be terminated by a newline
        optional($._statement)
      ),

    _escaped_newline: _ =>
      token(seq('\\', /\r?\n/)),

    _newline: _ =>
      token(/\r?\n/),

    _statement: $ =>
      choice(
        $.plot_command,
        $.splot_command,
        $.fit_command,
        $.set_command,
        $.unset_command,
        $.load_command,
        $.pause_command,
        $.reset_command,
        $.print_command,
        $.assignment,
        $.array_definition,
        $.function_definition,
        $.loop
      ),

    // --- Definitions ---

    assignment: $ =>
      seq(
        field('name', $.identifier),
        optional(seq(
          '[', $.expression, ']'
        )),
        '=',
        $.expression
      ),

    array_definition: $ =>
      seq(
        'array',
        field('name', $.identifier),
        '[',
        $._expression_basic,
        ']'
      ),

    function_definition: $ =>
      seq(
        field('name', $.identifier),
        $.parameter_list,
        '=',
        $.expression
      ),

    parameter_list: $ =>
      seq(
        '(',
        optional(sep1($.identifier, ',')),
        ')'
      ),

    // --- Commands ---

    plot_command: $ =>
      seq(
        'plot',
        $.plot_item_list
      ),

    splot_command: $ =>
      seq(
        'splot',
        $.plot_item_list
      ),

    fit_command: $ =>
      seq(
        'fit',
        $.expression,
        $._expression_string,
        'using',
        sep1($.expression, ':'),
        'via',
        sep1($._expression_basic, ',')
      ),

    load_command: $ =>
      seq(
        'load',
        $.string
      ),

    pause_command: $ =>
      seq(
        'pause',
        $._expression_basic,
        $._expression_basic,
      ),

    reset_command: _ =>
      'reset',

    print_command: $ =>
      seq(
        'print',
        $.expression_list
      ),

    set_command: $ =>
      seq(
        'set',
        $.set_keyword,
        optional($.set_arguments)
      ),

    set_keyword: _ =>
      choice(
       'angles', 'isosamples', 'pointintervalbox', 'warnings',
       'arrow', 'isosurface', 'pointsize', 'x2data',
       'autoscale', 'isotropic', 'polar', 'x2dtics',
       'bars', 'jitter', 'print', 'x2label',
       'bmargin', 'key', 'psdir', 'x2mtics',
       'border', 'label', 'range', 'x2range',
       'boxdepth', 'linetype', 'raxis', 'x2tics',
       'boxwidth', 'link', 'rgbmax', 'x2zeroaxis',
       'cbdata', 'lmargin', 'rlabel', 'xdata',
       'cbdtics', 'loadpath', 'rmargin', 'xdtics',
       'cblabel', 'locale', 'rrange', 'xlabel',
       'cbmtics', 'log', 'rtics', 'xmtics',
       'cbrange', 'logscale', 'samples', 'xrange',
       'cbtics', 'macros', 'size', 'xtics',
       'chi_shapes', 'mapping', 'spiderplot', 'xyplane',
       'clabel', 'margin', 'style', 'xzeroaxis',
       'clip', 'margins', 'surface', 'y2data',
       'cntrlabel', 'micro', 'table', 'y2dtics',
       'cntrparam', 'minussign', 'term', 'y2label',
       'color', 'missing', 'terminal', 'y2mtics',
       'colorbox', 'monochrome', 'termoption', 'y2range',
       'colormap', 'mouse', 'theta', 'y2tics',
       'colorsequence', 'mttics', 'tics', 'y2zeroaxis',
       'contour', 'multiplot', 'ticscale', 'ydata',
       'contourfill', 'mx2tics', 'ticslevel', 'ydtics',
       'cornerpoles', 'mxtics', 'time_specifiers', 'ylabel',
       'dashtype', 'my2tics', 'timefmt', 'ymtics',
       'datafile', 'mytics', 'timestamp', 'yrange',
       'date_specifiers', 'mztics', 'title', 'ytics',
       'decimalsign', 'nonlinear', 'tmargin', 'yzeroaxis',
       'dgrid3d', 'object', 'trange', 'zdata',
       'dummy', 'offsets', 'ttics', 'zdtics',
       'encoding', 'origin', 'urange', 'zero',
       'errorbars', 'output', 'vgrid', 'zeroaxis',
       'fit', 'overflow', 'view', 'zlabel',
       'fontpath', 'palette', 'vrange', 'zmtics',
       'format', 'parametric', 'vxrange', 'zrange',
       'grid', 'paxis', 'vyrange', 'ztics',
       'hidden3d', 'pixmap', 'vzrange', 'zzeroaxis',
       'history', 'pm3d', 'walls'
    ),

    set_argument: $ =>
      prec.left(sep1($._expression_basic, ',')),

    set_arguments: $ =>
      choice(
        repeat1($.set_argument),
        seq('(', sep1($.set_argument, ','), ')'),
        $.range
      ),

    unset_command: $ =>
      seq(
        'unset',
        $.set_keyword
      ),

    // --- Plot specifications ---

    plot_item_list: $ =>
      sep1($.plot_item, ','),

    plot_item: $ =>
      seq(
        repeat($.range),
        $.expression,
        repeat($.plot_option)
      ),

    plot_option: $ =>
      choice(
        $.using_clause,
        $.with_clause,
        $.title_clause,
        'notitle'
      ),

    using_clause: $ =>
      seq(
        'using',
        sep1($.expression, ':')
      ),

    with_clause: $ =>
      seq(
        'with',
        $.identifier
      ),

    title_clause: $ =>
      seq(
        'title',
        $.string
      ),

    // --- Loops ---
    loop: $ =>
      seq(
        'do',
        'for',
        $.iterator,
        $.do_clause,
      ),

    iterator: $ =>
      seq(
        '[',
        $.identifier,
        '=',
        $._range_endpoint,
        ':',
        $._range_endpoint,
        optional(seq(':', $._range_endpoint)),
        ']'
      ),

    do_clause: $ =>
      choice(
        $._statement,
        seq(
          '{',
          $._newline,
          repeat(seq($._statement, $._newline)),
          '}'
        )
      ),

    // --- Expressions ---

    expression_list: $ =>
      sep1($.expression, ','),

    _array_access: $ =>
      seq(
        $.identifier,
        '[',
        $.expression,
        ']'
      ),

    _expression_string: $ =>
      repeat1(choice(
        $.string,
        $.identifier
      )),

    _expression_basic: $ =>
      prec.left(choice(
        $.number,
        $.function_call,
        $._array_access,
        $._expression_string,
        $._expression_unary
      )),

    expression: $ =>
      choice(
        $._expression_basic,
        $._expression_binary,
        $._expression_ternary,
        $._expression_parenthesized
      ),

    _expression_parenthesized: $ =>
      seq(
        '(',
        $.expression,
        ')'
      ),

    _expression_unary: $ =>
      prec.right(seq(
        choice('-', '+', '$'),
        $.expression
      )),

    _expression_binary: $ =>
      prec.left(seq(
        $.expression,
        $.operator,
        $.expression
      )),

    _expression_ternary: $ =>
      prec.right(seq(
        $.expression,
        '?',
        $.expression,
        ':',
        $.expression
      )),

    operator: _ =>
      choice(
        '+', '-', '*', '/', '**',
        '==', '!=', '<', '<=', '>', '>='
      ),

    // --- Function calls ---

    function_call: $ =>
      prec.left(seq(
        field('name', choice($.builtin_function, $.identifier)),
        '(', 
        optional($.expression_list),
        ')'
      )),

    builtin_function: _ =>
      choice(
        'abs',
        'acos',
        'asin',
        'atan',
        'cos',
        'exp',
        'log',
        'log10',
        'sin',
        'sprintf',
        'sqrt',
        'tan',
      ),

    // --- Atoms ---

    identifier: _ =>
      /[a-zA-Z_][a-zA-Z0-9_]*/,

    number: _ =>
      token(
        /(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?/
      ),

    string: _ =>
      token(choice(
        seq(
          '"',
          repeat(choice(
            /[^"\\]/,
            /\\./
          )),
          '"'
        ),
        seq(
          '\'',
          repeat(choice(
            /[^'\\]/,
            /\\./
          )),
          '\''
        )
      )),

    _range_endpoint: $ =>
      choice(
        '*',
        $.expression
      ),

    range: $ =>
      seq(
        '[', $._range_endpoint, ':', $._range_endpoint, ']'),

    // --- Comments ---

    comment: $ =>
      token(seq('#', /[^\n]*\n/,)),
  }
});

function sep1(rule, separator) {
  return seq(rule, repeat(seq(separator, rule)));
}
