module codeberg.org/maribu/tree-sitter-proverif

go 1.22

require github.com/tree-sitter/go-tree-sitter v0.24.0
