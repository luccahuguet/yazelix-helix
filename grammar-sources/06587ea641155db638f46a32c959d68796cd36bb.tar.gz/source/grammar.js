/**
 * @file GoFormatString grammar for tree-sitter
 * @author kpbaks <kristoffer.pbs@tuta.io>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

// https://cs.opensource.google/go/go/+/refs/tags/go1.24.5:src/fmt/format.go
module.exports = grammar({
  name: "go_format_string",

  // whitespace is meaningful, so we disallow any kind of extra nodes,
  // to avoid having to write `token.immediate(...)` everywhere.
  extras: $ => [],

  rules: {
    format_string: $ =>
      seq(
        $.text,
        repeat(
          seq(
            $._maybe_format,
            $.text
          )
        )
      ),

    _maybe_format: $ => choice($.escaped_percent_sign, $.format_specifier),

    format_specifier: $ => seq(
      "%",
      // NOTE: multiple usages of the same flag in a verb is not malformed
      // e.g. "%## ++s" is equivalent to "%# +s"
      // Therefore we can simply use `repeat()` instead of writing an external scanner
      repeat($.flag),
      optional($.explicit_argument_index_expr),
      optional($._width_and_precision),
      $.verb,
    ),

    // `fmt.Sprintf("%[2]d %[1]d\n", 11, 22)`
    explicit_argument_index: _ => /[0-9]+/,
    explicit_argument_index_expr: $ => seq("[", $.explicit_argument_index, "]"),

    // "Either or both of the flags may be replaced with the character '*', causing their values to be obtained from the next operand (preceding the one to format), which must be of type int."
    //
    // %f     default width, default precision
    // %9f    width 9, default precision
    // %.2f   default width, precision 2
    // %9.2f  width 9, precision 2
    // %9.f   width 9, precision 0
    // %*d
    // %.*f
    // %*.f
    // %*.*f
    asterisk: _ => "*",
    width: $ => choice($.asterisk, /[0-9]+/),
    precision: $ => choice($.asterisk, /[0-9]*/),
    _width_and_precision: $ =>
      choice(
        // %8d
        // %8.d
        // %8.2f
        seq(
          $.width,
          optional("."),
          optional($.precision)
        ),
        // %.2f
        seq(".", $.precision)
      ),

    // https://pkg.go.dev/fmt#hdr-Printing
    verb: $ => choice(
      "v", // the value in a default format
      "T", // Go-syntax representation of the type of the value
      "t", // the word true or false
      "b", //	base 2
      "c", //	the character represented by the corresponding Unicode code point
      "d", //	base 10
      "e", // scientific notation, e.g. -1.234456e+78
      "E", // scientific notation, e.g. -1.234456E+78
      "f", // decimal point but no exponent, e.g. 123.456
      "F", // synonym for %f
      "g", // %e for large exponents, %f otherwise
      "G", // %E for large exponents, %F otherwise
      "o", //	base 8
      "O", //	base 8 with 0o prefix
      "q", //	a single-quoted character literal safely escaped with Go syntax.
      "x", //	base 16, with lower-case letters for a-f
      "X", //	base 16, with upper-case letters for A-F
      "U", //	Unicode format: U+1234; same as "U+%04X"
      "s", // string
      "p", //	address of 0th element in base 16 notation, with leading 0x
      "w", // error in fmt.Errorf
    ),

    escaped_percent_sign: _ => "%%",
    // https://cs.opensource.google/go/go/+/refs/tags/go1.24.5:src/fmt/print.go;l=1042-1057
    // https://cs.opensource.google/go/go/+/refs/tags/go1.24.5:src/fmt/print.go;l=188-202
    flag: _ => choice("+", "-", "#", " ", "0"),

    text: _ => /[^%]*/
  }
});
