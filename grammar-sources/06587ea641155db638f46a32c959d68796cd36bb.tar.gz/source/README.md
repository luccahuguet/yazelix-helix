# tree-sitter-go-format-string

tree-sitter grammar for Go's format string syntax e.g. `fmt.Sprintf` and `log.Panicf`.

## Showcase

Editor: [Helix](https://helix-editor.com/)

![showcase](./docs/showcase.png)

## Editor Support

| Editor | Supported |
|--- | --- |
| [Helix](https://helix-editor.com/) | Merged in [`22e60d6`](https://github.com/helix-editor/helix/commit/22e60d6a7184a38e79ca8a3af7df90af067c7f51) |

## Resources referenced

- https://pkg.go.dev/fmt
- https://pkg.go.dev/log
- https://cs.opensource.google/go/go/+/refs/tags/go1.24.5:src/fmt/format.go
