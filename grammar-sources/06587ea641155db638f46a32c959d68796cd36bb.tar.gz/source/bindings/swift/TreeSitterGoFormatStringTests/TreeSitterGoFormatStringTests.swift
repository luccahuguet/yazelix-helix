import XCTest
import SwiftTreeSitter
import TreeSitterGoFormatString

final class TreeSitterGoFormatStringTests: XCTestCase {
    func testCanLoadGrammar() throws {
        let parser = Parser()
        let language = Language(language: tree_sitter_go_format_string())
        XCTAssertNoThrow(try parser.setLanguage(language),
                         "Error loading GoFormatString grammar")
    }
}
