package tree_sitter_go_format_string_test

import (
	"testing"

	tree_sitter "github.com/tree-sitter/go-tree-sitter"
	tree_sitter_go_format_string "codeberg.org/kpbaks/tree-sitter-go-format-string/bindings/go"
)

func TestCanLoadGrammar(t *testing.T) {
	language := tree_sitter.NewLanguage(tree_sitter_go_format_string.Language())
	if language == nil {
		t.Errorf("Error loading GoFormatString grammar")
	}
}
