package main

import (
    "fmt"
    "log"
    "os"
)

func main() {
    fmt.Printf("hello %s", "world")

    _ = fmt.Sprintf("My name is %*s, and I am %3d years old", "kpbaks", 26)

    log.Panicf("You can escape %%")

    myLogger := log.New(os.Stderr, "tree-sitter", log.Ldate)

    myLogger.Printf("You can use explicit indices %[2]s %[1]3.*f", 3.14, "foo")

    fmt.Fprintf(os.Stderr, "And specify flags %#+0 v", myLogger)

    var name string
    var age int
    n, err := fmt.Sscanf("Kim is 22 years old", "%s is %d years old", &name, &age)
}
