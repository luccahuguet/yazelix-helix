# TreeSitter grammar for PTX (Parallel Thread Execution)

Add the following to `~/.config/helix/languages.toml`:
```toml
[[language]]
name = "ptx"
scope = "source.ptx"
file-types = ["ptx"]
language-server = { command = "", args = [] }  # No LSP server available yet, someone else can do that...
roots = []
auto-format = false

[grammar]
name = "ptx"
source = { git = "https://codeberg.org/jer-gremlin/tree-sitter-ptx.git", rev = "WHATEVER LATEST IS..." }
# or use the .so if you compile it from source, but DO make sure your .config/helix/grammars/ptx/*.scm etc are there (copy them from this repo)
```

## License

MIT