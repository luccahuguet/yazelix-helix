module.exports = grammar({
  name: 'ptx',

  extras: $ => [
    /\s/,
    $.comment,
  ],

  conflicts: $ => [
    [$.global_declaration],
    [$.const_declaration],
    [$.local_declaration],
    [$.param_declaration],
  ],

  rules: {
    // The top-level rule for a PTX file
    source_file: $ => repeat(choice(
      $.version_directive,
      $.target_directive,
      $.address_size_directive,
      $.file_directive,
      $.section_directive,
      $.global_declaration,
      $.const_declaration,
      $.local_declaration,
      $.param_declaration,
      $.func_declaration,
      $.entry_declaration,
      $.label,
      $.instruction,
      $.visibility_directive,
      $.pragma_directive,
    )),

    // Directives
    version_directive: $ => seq('.version', $.number),
    
    target_directive: $ => seq('.target', $.target_spec),
    
    address_size_directive: $ => seq('.address_size', $.number),
    
    file_directive: $ => seq('.file', $.number, $.string),
    
    section_directive: $ => seq('.section', $.section_spec, $.string),
    
    visibility_directive: $ => choice('.visible', '.extern'),
    
    pragma_directive: $ => seq('.pragma', $.string),

    target_spec: $ => choice(
      'sm_20', 'sm_30', 'sm_35', 'sm_37', 'sm_50', 'sm_52', 'sm_53',
      'sm_60', 'sm_61', 'sm_62', 'sm_70', 'sm_72', 'sm_75', 'sm_80', 'sm_86', 'sm_87', 'sm_89', 'sm_90',
      'compute_30', 'compute_35', 'compute_37', 'compute_50', 'compute_52', 'compute_53',
      'compute_60', 'compute_61', 'compute_62', 'compute_70', 'compute_72', 'compute_75', 'compute_80', 'compute_86', 'compute_87', 'compute_89', 'compute_90'
    ),

    section_spec: $ => choice('.sdata', '.sdata.alignment', '.bss', '.bss.alignment'),

    // Data type declarations
    data_type: $ => choice(
      'u8', 'u16', 'u32', 'u64',
      's8', 's16', 's32', 's64',
      'b8', 'b16', 'b32', 'b64',
      'f16', 'f16x2', 'f32', 'f64',
      'pred'
    ),

    // Memory space specifiers
    memory_space: $ => choice(
      '.global', '.const', '.param', '.local', '.shared', '.tex'
    ),

    // Declaration rules
    global_declaration: $ => prec.left(1, seq(
      optional($.visibility_directive),
      '.global', 
      $.data_type,
      '[',
      $.identifier,
      ']',
      optional(seq('=', $.initializer_list))
    )),

    const_declaration: $ => prec.left(1, seq(
      optional($.visibility_directive),
      '.const', 
      $.data_type,
      '[',
      $.identifier,
      ']',
      optional(seq('=', $.initializer_list))
    )),

    local_declaration: $ => prec.left(1, seq(
      '.local', 
      $.data_type,
      '[',
      $.identifier,
      ']'
    )),

    param_declaration: $ => prec.left(1, seq(
      '.param', 
      $.data_type,
      '[',
      $.identifier,
      ']'
    )),

    func_declaration: $ => prec.left(1, seq(
      optional($.visibility_directive),
      '.func',
      optional(seq('<', $.func_signature, '>')),
      $.identifier,
      '(',
      optional($.parameter_list),
      ')',
      optional(seq(':', $.func_body))
    )),

    entry_declaration: $ => prec.left(1, seq(
      '.entry',
      $.identifier,
      '(',
      optional($.parameter_list),
      ')',
      optional(seq(':', $.func_body))
    )),

    func_signature: $ => seq(
      $.data_type,
      $.identifier,
      repeat(seq(',', $.data_type, $.identifier))
    ),

    parameter_list: $ => seq(
      $.parameter,
      repeat(seq(',', $.parameter))
    ),

    parameter: $ => seq(
      optional($.memory_space),
      $.data_type,
      $.identifier
    ),

    initializer_list: $ => seq(
      '{',
      $.initializer,
      repeat(seq(',', $.initializer)),
      '}'
    ),

    initializer: $ => choice(
      $.number,
      $.string,
      $.float_literal
    ),

    func_body: $ => prec.left(0, seq(
      choice($.variable_declaration, $.instruction, $.label),
      repeat(choice($.variable_declaration, $.instruction, $.label))
    )),

    variable_declaration: $ => seq(
      $.data_type,
      $.identifier
    ),

    // Instructions
    instruction: $ => prec.left(0, seq(
      $.opcode,
      optional($.instruction_modifier),
      optional($.predicate),
      optional($.operand_list)
    )),

    opcode: $ => choice(
      // Arithmetic instructions
      'add', 'sub', 'mul', 'div', 'rem', 'neg', 'abs', 'min', 'max',
      // Bitwise instructions
      'and', 'or', 'not', 'xor', 'popc', 'clz', 'ffs', 'bfind',
      // Comparison instructions
      'set', 'setp', 'selp',
      // Movement instructions
      'mov', 'cvt', 'cvt.rn', 'cvt.rm', 'cvt.rp', 'cvt.rz',
      // Memory instructions
      'ld', 'st', 'atom', 'red', 'membar',
      // Control flow instructions
      'bra', 'call', 'ret', 'exit',
      // Texture instructions
      'tex', 'tld4', 'tld', 'txq', 'tsa',
      // Special instructions
      'bar', 'vote', 'shfl', 'match', 'prmt'
    ),

    instruction_modifier: $ => choice(
      '.u8', '.u16', '.u32', '.u64',
      '.s8', '.s16', '.s32', '.s64',
      '.b8', '.b16', '.b32', '.b64',
      '.f16', '.f16x2', '.f32', '.f64',
      '.pred',
      '.global', '.const', '.param', '.local', '.shared',
      '.cta', '.gl', '.sys',
      '.approx', '.full',
      '.rni', '.rne', '.rnm', '.rup', '.rdo',
      '.warp', '.sync'
    ),

    predicate: $ => seq(
      '@',
      $.identifier
    ),

    operand_list: $ => seq(
      $.operand,
      repeat(seq(',', $.operand))
    ),

    operand: $ => choice(
      $.register,
      $.identifier,
      $.number,
      $.float_literal,
      $.address,
      $.memory_access
    ),

    register: $ => seq(
      '%',
      choice(
        /[a-zA-Z_][a-zA-Z0-9_]*/,  // Regular register names
        /\d+/                      // Numbered registers like %r1, %f2
      )
    ),

    address: $ => seq(
      '&',
      $.identifier
    ),

    memory_access: $ => seq(
      '[',
      $.operand,
      optional(seq('+', $.operand)),
      ']'
    ),

    // Labels
    label: $ => seq(
      $.identifier,
      ':'
    ),

    // Literals and identifiers
    identifier: $ => /[a-zA-Z_][a-zA-Z0-9_]*/,

    number: $ => /0[xX][0-9a-fA-F]+|[0-9]+/,

    float_literal: $ => /-?[0-9]+\.[0-9]*([eE][+-]?[0-9]+)?/,

    string: $ => /"([^"\\]|\\.)*"/,

    comment: $ => token(seq('//', /.*/)),
  }
});