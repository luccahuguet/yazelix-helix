# tree-sitter-shellcheckrc

## Showcase

![](./assets/showcase.png)
