module codeberg.org/kpbaks/tree-sitter-shellcheckrc

go 1.22

require github.com/tree-sitter/go-tree-sitter v0.24.0
