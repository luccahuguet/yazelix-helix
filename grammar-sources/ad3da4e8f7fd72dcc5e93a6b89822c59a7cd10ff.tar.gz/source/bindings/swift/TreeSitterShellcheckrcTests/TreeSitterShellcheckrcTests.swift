import XCTest
import SwiftTreeSitter
import TreeSitterShellcheckrc

final class TreeSitterShellcheckrcTests: XCTestCase {
    func testCanLoadGrammar() throws {
        let parser = Parser()
        let language = Language(language: tree_sitter_shellcheckrc())
        XCTAssertNoThrow(try parser.setLanguage(language),
                         "Error loading Shellcheckrc grammar")
    }
}
