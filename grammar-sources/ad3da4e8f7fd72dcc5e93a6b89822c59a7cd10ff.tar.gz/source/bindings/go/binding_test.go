package tree_sitter_shellcheckrc_test

import (
	"testing"

	tree_sitter "github.com/tree-sitter/go-tree-sitter"
	tree_sitter_shellcheckrc "codeberg.org/kpbaks/tree-sitter-shellcheckrc/bindings/go"
)

func TestCanLoadGrammar(t *testing.T) {
	language := tree_sitter.NewLanguage(tree_sitter_shellcheckrc.Language())
	if language == nil {
		t.Errorf("Error loading Shellcheckrc grammar")
	}
}
