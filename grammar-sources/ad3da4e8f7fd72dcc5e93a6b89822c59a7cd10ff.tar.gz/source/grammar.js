/**
 * @file tree-sitter grammar for shellcheckrc files
 * @author kpbaks <kristoffer.pbs@tuta.io>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

module.exports = grammar({
  name: "shellcheckrc",

  extras: $ => [
    $._whitespace,
    $.comment,
  ],

  rules: {
    shellcheckrc_file: $ => repeat($._directive),
    _directive: $ => choice(
      $.disable_directive,
      $.enable_directive,
      $.extended_analysis_directive,
      $.external_sources_directive,
      $.source_directive,
      $.source_path_directive,
      $.shell_directive,
    ),

    _disable_value: $ => choice(
      $.all,
      $._rule_id_list,
    ),
    disable_directive: $ => seq("disable", token.immediate("="), $._disable_value),
    enable_directive: $ => seq("enable", token.immediate("="), choice($.all, $.identifier)),
    extended_analysis_directive: $ => seq("extended-analysis", token.immediate("="), $.boolean),
    external_sources_directive: $ => seq("external-sources", token.immediate("="), $.boolean),
    _source_value: $ => choice($.string, $.identifier),
    source_directive: $ => seq("source", token.immediate("="), $._source_value),
    source_path_directive: $ => seq("source-path", token.immediate("="), $._source_value),
    shell_directive: $ => seq("shell", token.immediate("="), $.shell),

    all: _ => token(prec(5, "all")),
    SCRIPTDIR: _ => token(prec(5, "SCRIPTDIR")),

    shell: _ => choice("sh", "bash", "dash", "ksh", "busybox"),

    // Disables a comma separated list of error codes for the following command.  The command  can  be  a
    // simple  command like echo foo, or a compound command like a function definition, subshell block or
    // loop.  A range can be be specified with a dash, e.g.  disable=SC3000-SC4000 to exclude 3xxx.   All
    // warnings can be disabled with disable=all.
    rule_id: $ => seq(
      optional(token.immediate("SC")),
      field("id", $.integer)
    ),
    _rule_id: $ => choice($.rule_id, $.rule_id_range),
    _rule_id_list: $ => seq(
      $._rule_id,
      repeat(seq(token.immediate(","), $._rule_id))
    ),

    rule_id_range: $ => prec(2,
      seq(
        field("from", $.rule_id),
        token.immediate("-"),
        field("to", $.rule_id),
      ),
    ),

    integer: _ => /[0-9]+/,
    boolean: _ => choice("true", "false"),
    string: $ => prec(1, choice(
      seq("'", /[^']*/, "'"),
      seq('"', /[^"]*/, '"')
    )),
    // string_content: _ => /[^']*/,
    // quoted_string:

    identifier: _ => prec(-9, /[a-zA-Z0-9-_./]+/),

    comment: _ => token(seq('#', /.*/)),
    _whitespace: _ => /[ \t\r\n]+/,
  }
});
