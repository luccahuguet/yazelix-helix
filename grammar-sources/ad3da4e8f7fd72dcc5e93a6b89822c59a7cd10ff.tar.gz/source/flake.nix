{
  description = "tree-sitter grammar shellcheckrc files";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=nixos-unstable";
    flake-parts.url = "github:hercules-ci/flake-parts";
  };

  outputs =
    {
      self,
      nixpkgs,
      flake-parts,
      ...
    }@inputs:
    flake-parts.lib.mkFlake { inherit inputs; } (
      {
        config,
        withSystem,
        moduleWithSystem,
        ...
      }:
      {
        imports = [ ];
        flake = { };
        systems = [
          "x86_64-linux"
          "x86_64-darwin"
          "aarch64-linux"
          "aarch64-darwin"
        ];
        perSystem =
          {
            config,
            pkgs,
            self',
            ...
          }:
          let
            tree-sitter' = (pkgs.tree-sitter.override { webUISupport = true; });
          in
          {
            devShells.default = pkgs.mkShell {
              # inherit (self'.packages.default) nativeBuildInputs;
              packages = with pkgs; [
                tree-sitter'
                emscripten
                nodejs
                oxlint
                typescript-language-server

                clang-tools # clangd for src/scanner.c
                libclang.lib
              ];
            };

            packages.default =
              with builtins;
              let
                spec = fromJSON (readFile ./tree-sitter.json);
                inherit (spec.metadata) version;

              in
              pkgs.tree-sitter.buildGrammar {
                src = ./.;
                inherit version;
                language = "tree-sitter-shellcheckrc";
                generate = true;
              };
          };
      }
    );
}
