https://github.com/nvim-treesitter/nvim-treesitter/discussions/885
